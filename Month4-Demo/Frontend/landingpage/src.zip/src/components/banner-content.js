import PropTypes from "prop-types";
import "./banner-content.css";

const BannerContent = ({ className = "" }) => {
  return (
    <div className={`banner-content ${className}`}>
      <div className="why-choose-us">
        <h1 className="why-choose-us1">{`Why Choose Us? `}</h1>
        <button className="button3">
          <img
            className="iconsarrowsright"
            alt=""
            src="/iconsarrowsright.svg"
          />
          <div className="text19">
            <div className="barcode-app-stores">Explore More</div>
            <img
              className="iconsarrowsright-small"
              alt=""
              src="/iconsarrowsrightsmall.svg"
            />
          </div>
        </button>
      </div>
    </div>
  );
};

BannerContent.propTypes = {
  className: PropTypes.string,
};

export default BannerContent;
