import PropTypes from "prop-types";
import "./frame-component1.css";

const FrameComponent1 = ({ className = "" }) => {
  return (
    <section className={`offers-wrapper ${className}`}>
      <div className="offers">
        <div className="discounts">
          <b className="special-offers">{`Special offers `}</b>
          <div className="discount-options">
            <div className="discount-list">
              <div className="photo-1">
                <div className="button4">
                  <img
                    className="vuesaxoutlinearrow-down-icon"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="deals-discover">Deals discover</div>
                  <img
                    className="iconsarrowsarrow-right"
                    alt=""
                    src="/iconsarrowsarrowright.svg"
                  />
                </div>
                <div className="button5">
                  <img
                    className="vuesaxoutlinearrow-down-icon1"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="loyalty-discounts">Loyalty Discounts</div>
                  <div className="iconsarrowsarrow-right-wrapper">
                    <img
                      className="iconsarrowsarrow-right1"
                      loading="lazy"
                      alt=""
                      src="/iconsarrowsarrowright-1.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="photo-2">
                <div className="button6">
                  <img
                    className="vuesaxoutlinearrow-down-icon2"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="early-booking-discounts">
                    Early Booking Discounts
                  </div>
                  <div className="iconsarrowsarrow-right-container">
                    <img
                      className="iconsarrowsarrow-right2"
                      loading="lazy"
                      alt=""
                      src="/iconsarrowsarrowright-1.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="photo-3">
                <div className="button7">
                  <img
                    className="vuesaxoutlinearrow-down-icon3"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="last-minute-deals">Last-Minute Deals</div>
                  <div className="iconsarrowsarrow-right-frame">
                    <img
                      className="iconsarrowsarrow-right3"
                      loading="lazy"
                      alt=""
                      src="/iconsarrowsarrowright.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="down">
              <div className="photo-4">
                <button className="button8">
                  <img
                    className="vuesaxoutlinearrow-down-icon4"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="text26">
                    <div className="family-packages">Family Packages</div>
                    <div className="frame-div">
                      <img
                        className="iconsarrowsarrow-right4"
                        alt=""
                        src="/iconsarrowsarrowright-1.svg"
                      />
                    </div>
                  </div>
                </button>
              </div>
              <div className="photo-5">
                <div className="button9">
                  <img
                    className="vuesaxoutlinearrow-down-icon5"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="text27">
                    <div className="birthday-or-anniversary">
                      Birthday or Anniversary Specials
                    </div>
                    <div className="iconsarrowsarrow-right-wrapper1">
                      <img
                        className="iconsarrowsarrow-right5"
                        loading="lazy"
                        alt=""
                        src="/iconsarrowsarrowright-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="photo-6">
                <div className="button10">
                  <img
                    className="vuesaxoutlinearrow-down-icon6"
                    alt=""
                    src="/vuesaxoutlinearrowdown.svg"
                  />
                  <div className="text28">
                    <div className="referral-programs">Referral Programs</div>
                    <div className="iconsarrowsarrow-right-wrapper2">
                      <img
                        className="iconsarrowsarrow-right6"
                        loading="lazy"
                        alt=""
                        src="/iconsarrowsarrowright.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="make-a-comprasion">
          <div className="cards">
            <div className="make-a-compraion-text">
              <h1 className="make-a-comprasion1">{`Make a Comprasion `}</h1>
            </div>
            <div className="make-a-compoasion-cards">
              <div className="photo-left">
                <b className="the-past-offers">
                  The past offers with the highest reviews outshine others,
                  standing as a testament to their exceptional quality.
                </b>
              </div>
              <div className="photo-right">
                <b className="ring-in-the">
                  Ring in the new year with iconic moments and unforgettable
                  memories in New York City
                </b>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent1;
