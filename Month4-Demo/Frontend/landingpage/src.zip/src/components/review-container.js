import Component from "./component";
import PropTypes from "prop-types";
import "./review-container.css";

const ReviewContainer = ({ className = "" }) => {
  return (
    <section className={`review-container ${className}`}>
      <div className="back-review-cards">
        <div className="review-cards">
          <Component
            iconFlagIconSet43Yt="/icon--flagiconset--43--yt.svg"
            teacherTerece="Teacher Terece"
            returningToThisHotelIsAlw="Returning to this hotel is always a delight – their loyalty program showers us with exclusive discounts and amazing perks!"
            photo="/photo-11@2x.png"
          />
          <div className="component-2">
            <div className="text33">
              <div className="text34">
                <div className="beyu">
                  <div className="icon-flag-icon-set-43-n-wrapper">
                    <img
                      className="icon-flag-icon-set-43-n"
                      loading="lazy"
                      alt=""
                      src="/icon--flagiconset--43--no.svg"
                    />
                  </div>
                  <div className="beyu68">BEYU68£</div>
                </div>
                <div className="text35">
                  <div className="text36">
                    <div className="accessing-easyset24-extraordin">
                      Accessing EasySet24 extraordinary special offers makes
                      always our journey even more unforgettable.
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <img
              className="photo-icon2"
              loading="lazy"
              alt=""
              src="/photo-21@2x.png"
            />
          </div>
          <Component
            iconFlagIconSet43Yt="/icon--flagiconset--43--ca.svg"
            teacherTerece="Elina13ay"
            returningToThisHotelIsAlw="Weekends here are pure bliss with their carefully crafted packages, and the extended stay discounts make relaxation even more enticing."
            photo="/photo-31@2x.png"
            propMinWidth="74px"
            propLetterSpacing="unset"
          />
        </div>
      </div>
    </section>
  );
};

ReviewContainer.propTypes = {
  className: PropTypes.string,
};

export default ReviewContainer;
