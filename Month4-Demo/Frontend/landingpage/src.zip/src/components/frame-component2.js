import PropTypes from "prop-types";
import "./frame-component2.css";

const FrameComponent2 = ({ className = "" }) => {
  return (
    <section className={`special-offers-cards-wrapper ${className}`}>
      <div className="special-offers-cards">
        <div className="card-row">
          <div className="special-offer-hotels-wrapper">
            <div className="special-offer-hotels">
              <div className="special-offer-hotels1">
                <div className="special-flight-offers">
                  <img
                    className="image-1-icon"
                    loading="lazy"
                    alt=""
                    src="/image-1@2x.png"
                  />
                  <div className="text-berlin">
                    <div className="text21">
                      <b className="berlin">Belgium</b>
                      <div className="wed-25-jan-fri">
                        Bruxelles Gare du Midi
                      </div>
                    </div>
                  </div>
                </div>
                <div className="tag">
                  <img
                    className="customer-service-icon"
                    alt=""
                    src="/customer-service.svg"
                  />
                  <img
                    className="headquarters-icon"
                    alt=""
                    src="/vector-10-1.svg"
                  />
                  <img className="subtract-icon" alt="" src="/subtract.svg" />
                  <div className="special-offer">{`Best Deals  `}</div>
                </div>
              </div>
            </div>
          </div>
          <div className="special-offer-hotel-container-parent">
            <div className="special-offer-hotel-container">
              <div className="special-offer-hotels2">
                <div className="special-offer-hotels3">
                  <div className="special-flight-offers1">
                    <img
                      className="image-1-icon1"
                      loading="lazy"
                      alt=""
                      src="/image-1-1@2x.png"
                    />
                    <div className="text-berlin1">
                      <div className="text22">
                        <b className="berlin1">New Jersey</b>
                        <div className="wed-25-jan-fri1">Windsor</div>
                      </div>
                    </div>
                  </div>
                  <div className="tag1">
                    <img
                      className="buttonconfirm-icon"
                      alt=""
                      src="/customer-service.svg"
                    />
                    <img
                      className="tag-child"
                      loading="lazy"
                      alt=""
                      src="/vector-10-1.svg"
                    />
                    <img
                      className="subtract-icon1"
                      alt=""
                      src="/subtract.svg"
                    />
                    <div className="special-offer1">{`Best Deals  `}</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="special-offer-hotels4">
              <div className="special-offer-hotels5">
                <div className="special-flight-offers2">
                  <img
                    className="image-1-icon2"
                    loading="lazy"
                    alt=""
                    src="/image-1-2@2x.png"
                  />
                  <div className="text-berlin2">
                    <div className="text23">
                      <b className="berlin2">Nepal</b>
                      <div className="wed-25-jan-fri2">Hyatt Regency K</div>
                    </div>
                  </div>
                </div>
                <div className="tag2">
                  <img
                    className="balitravelguide-icon"
                    alt=""
                    src="/customer-service.svg"
                  />
                  <img
                    className="auto-layout-activities"
                    alt=""
                    src="/vector-10-1.svg"
                  />
                  <img className="subtract-icon2" alt="" src="/subtract.svg" />
                  <div className="special-offer2">Best Deals</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="offer-container-wrapper">
          <div className="offer-container">
            <div className="special-offer-hotel-container1">
              <div className="special-offer-hotels6">
                <div className="special-offer-hotels7">
                  <div className="special-flight-offers3">
                    <img
                      className="image-1-icon3"
                      loading="lazy"
                      alt=""
                      src="/image-1-3@2x.png"
                    />
                    <div className="text-berlin3">
                      <div className="text24">
                        <b className="berlin3">Amsterdam</b>
                        <div className="wed-25-jan-fri3">Bunk</div>
                      </div>
                    </div>
                  </div>
                  <div className="tag3">
                    <img
                      className="network-links-icon"
                      alt=""
                      src="/customer-service.svg"
                    />
                    <img
                      className="email-info-icon"
                      alt=""
                      src="/vector-10-1.svg"
                    />
                    <img
                      className="subtract-icon3"
                      alt=""
                      src="/subtract.svg"
                    />
                    <div className="special-offer3">{`Best Deals  `}</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="special-offer-hotels8">
              <div className="special-offer-hotels9">
                <div className="special-flight-offers4">
                  <img
                    className="image-1-icon4"
                    loading="lazy"
                    alt=""
                    src="/image-1-4@2x.png"
                  />
                  <div className="text-berlin4">
                    <div className="text25">
                      <b className="berlin4">Gothenburg</b>
                      <div className="wed-25-jan-fri4">First Hotel G</div>
                    </div>
                  </div>
                </div>
                <div className="tag4">
                  <img
                    className="realtime-processor-icon"
                    alt=""
                    src="/customer-service.svg"
                  />
                  <img
                    className="stream-handler-icon"
                    alt=""
                    src="/vector-10-1.svg"
                  />
                  <img className="subtract-icon4" alt="" src="/subtract.svg" />
                  <div className="special-offer4">{`Best Deals  `}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent2.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent2;
