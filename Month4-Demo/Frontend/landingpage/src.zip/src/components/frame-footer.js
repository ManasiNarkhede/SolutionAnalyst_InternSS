import PropTypes from "prop-types";
import "./frame-footer.css";

const FrameFooter = ({ className = "" }) => {
  return (
    <div className={`frame-footer ${className}`}>
      <div className="under-the-footer-title">
        <div className="text-1-wrapper">
          <div className="text-1">
            <div className="icon">
              <img
                className="iconscharactercopyright"
                alt=""
                src="/iconscharactercopyright.svg"
              />
            </div>
            <div className="copyright-easyset24">Copyright EasySet24</div>
          </div>
        </div>
        <div className="text-2-wrapper">
          <div className="text-2">
            <div className="icon1">
              <img
                className="iconsofficeemail-down"
                alt=""
                src="/iconsofficeemaildown.svg"
              />
            </div>
            <div className="contact-details">
              <div className="easyset24gmailcom">easyset24@gmail.com</div>
            </div>
          </div>
        </div>
        <blockquote className="easyset24-seamless-journeys">
          "EasySet24: Seamless Journeys, Unrivalled Travel Wisdom!"
        </blockquote>
        <div className="text-3-wrapper">
          <div className="text-3">
            <img
              className="iconstravelslocal-two"
              alt=""
              src="/iconstravelslocaltwo.svg"
            />
            <div className="oxford-streetlondon">123 Oxford Street,London</div>
          </div>
        </div>
        <div className="text-4-wrapper">
          <div className="text-4">
            <div className="icon2">
              <img
                className="iconscommunicatephone-call1"
                alt=""
                src="/iconscommunicatephonecall-1.svg"
              />
            </div>
            <div className="phone1">
              <div className="div5">+44 20 7123 4567</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameFooter.propTypes = {
  className: PropTypes.string,
};

export default FrameFooter;
