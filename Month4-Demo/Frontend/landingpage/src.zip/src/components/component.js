import { useMemo } from "react";
import PropTypes from "prop-types";
import "./component.css";

const Component = ({
  className = "",
  iconFlagIconSet43Yt,
  teacherTerece,
  returningToThisHotelIsAlw,
  photo,
  propMinWidth,
  propLetterSpacing,
}) => {
  const teacherTereceStyle = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  const returningToThisContainerStyle = useMemo(() => {
    return {
      letterSpacing: propLetterSpacing,
    };
  }, [propLetterSpacing]);

  return (
    <div className={`component-1 ${className}`}>
      <div className="text29">
        <div className="text30">
          <div className="teacher">
            <div className="reviewer-flags">
              <img
                className="icon-flag-icon-set-43-y"
                loading="lazy"
                alt=""
                src={iconFlagIconSet43Yt}
              />
            </div>
            <div className="teacher-terece" style={teacherTereceStyle}>
              {teacherTerece}
            </div>
          </div>
          <div className="text31">
            <div className="text32">
              <div
                className="returning-to-this-container"
                style={returningToThisContainerStyle}
              >
                <p className="returning-to-this">{returningToThisHotelIsAlw}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <img className="photo-icon1" loading="lazy" alt="" src={photo} />
    </div>
  );
};

Component.propTypes = {
  className: PropTypes.string,
  iconFlagIconSet43Yt: PropTypes.string,
  teacherTerece: PropTypes.string,
  returningToThisHotelIsAlw: PropTypes.string,
  photo: PropTypes.string,

  /** Style props */
  propMinWidth: PropTypes.any,
  propLetterSpacing: PropTypes.any,
};

export default Component;
