import PropTypes from "prop-types";
import "./easy-set24-app-footer.css";

const EasySet24AppFooter = ({ className = "" }) => {
  return (
    <section className={`easyset24-app-footer ${className}`}>
      <div className="auto-layout">
        <div className="travel-description-and-click-o">
          <b className="go-further-with">Go Further With The EasySet24 App</b>
        </div>
        <div className="enjoy-savings-on">
          Enjoy savings on chosen hotels and flights when you book through the
          EasySet24 website. Additionally, earn One Key Cash for every booking
          made through the app.
        </div>
        <div className="text37">
          <div className="secured-by-europe">Secured By Europe GTP</div>
        </div>
      </div>
      <div className="auto-layout-scane-barcode">
        <div className="auto-layout-barcode-app-store">
          <img
            className="httpslottiefilescomanimat-icon"
            loading="lazy"
            alt=""
            src="/httpslottiefilescomanimationsappledownloadu6sucjunlb@2x.png"
          />
          <img
            className="qr-code-icon"
            loading="lazy"
            alt=""
            src="/qr-code.svg"
          />
        </div>
        <div className="auto-layout-barcode-google-pla">
          <img
            className="httpslottiefilescomanimat-icon1"
            loading="lazy"
            alt=""
            src="/httpslottiefilescomanimationsgoogleplaybadgegeekcfr3j6@2x.png"
          />
          <img
            className="qr-code-icon1"
            loading="lazy"
            alt=""
            src="/qr-code-1.svg"
          />
        </div>
      </div>
    </section>
  );
};

EasySet24AppFooter.propTypes = {
  className: PropTypes.string,
};

export default EasySet24AppFooter;
