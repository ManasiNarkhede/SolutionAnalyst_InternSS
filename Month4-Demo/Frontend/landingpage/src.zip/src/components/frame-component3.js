import PropTypes from "prop-types";
import "./frame-component3.css";

const FrameComponent3 = ({ className = "" }) => {
  return (
    <div className={`frame-parent ${className}`}>
      <div className="exclusive-hotel-search-wrapper">
        <h1 className="exclusive-hotel-search">Exclusive Hotel Search!</h1>
      </div>
      <div className="tabs">
        <div className="tab-review">
          <div className="text20">
            <b className="place-rules">Special offers</b>
          </div>
        </div>
        <div className="tab-review1">
          <b className="last-search">Last Search</b>
        </div>
        <div className="tab-review2">
          <b className="trending-destinations">trending destinations</b>
        </div>
        <div className="tab-review3">
          <b className="highest-reviewed">Highest Reviewed</b>
        </div>
        <div className="tab-review4">
          <b className="highest-reviewed1">Highest Reviewed</b>
        </div>
      </div>
    </div>
  );
};

FrameComponent3.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent3;
