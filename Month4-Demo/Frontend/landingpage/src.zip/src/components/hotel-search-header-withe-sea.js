import PropTypes from "prop-types";
import "./hotel-search-header-withe-sea.css";

const HotelSearchHeaderWitheSea = ({ className = "" }) => {
  return (
    <header className={`hotel-search-header-withe-sea ${className}`}>
      <div className="header-after-sign-in">
        <div className="header">
          <div className="search">
            <div className="logo">
              <img
                className="customer-service-link"
                loading="lazy"
                alt=""
                src="/vector.svg"
              />
              <b className="easyset-24">EasySet 24</b>
            </div>
            <div className="search-input-in-footer">
              <img
                className="iconsbasesearch"
                alt=""
                src="/iconsbasesearch.svg"
              />
            </div>
            <div className="icons">
              <div className="icons1">
                <div className="england">
                  <img className="button-icon" alt="" src="/button@2x.png" />
                </div>
                <div className="icon-buttons">
                  <div className="button">
                    <img
                      className="iconsmoneydollar"
                      alt=""
                      src="/iconsmoneydollar.svg"
                    />
                  </div>
                </div>
                <div className="icon-buttons1">
                  <div className="button1">
                    <img
                      className="iconscharacterhelp"
                      alt=""
                      src="/iconscharacterhelp.svg"
                    />
                  </div>
                </div>
                <div className="icon-buttons2">
                  <div className="button2">
                    <img
                      className="iconsbaselike"
                      alt=""
                      src="/iconsbaselike.svg"
                    />
                  </div>
                </div>
                <div className="phone">
                  <img
                    className="iconscommunicatephone-call"
                    alt=""
                    src="/iconscommunicatephonecall.svg"
                  />
                </div>
              </div>
              <div className="anna-name">
                <img
                  className="photo-icon"
                  loading="lazy"
                  alt=""
                  src="/photo@2x.png"
                />
                <div className="anna">
                  <b className="your-account">Your Account</b>
                  <div className="anna1">
                    <div className="anna-carinna">Anna Carinna</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="chip-menu">
            <div className="chips-trip">
              <div className="auto-layout-icon">
                <div className="link-button">Trip</div>
              </div>
            </div>
            <button className="chips-deals">
              <div className="div">
                <div className="text">%Deals</div>
              </div>
            </button>
            <button className="chips-hotel">
              <div className="div1">
                <b className="text1">Hotel</b>
              </div>
            </button>
            <div className="chips-flight">
              <div className="div2">
                <div className="text2">Flight</div>
              </div>
            </div>
            <div className="chips-apartment">
              <div className="div3">
                <div className="text3">Apartment</div>
              </div>
            </div>
            <button className="chips-camper">
              <div className="div4">
                <div className="text4">Camper</div>
              </div>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

HotelSearchHeaderWitheSea.propTypes = {
  className: PropTypes.string,
};

export default HotelSearchHeaderWitheSea;
