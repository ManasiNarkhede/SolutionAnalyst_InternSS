import PropTypes from "prop-types";
import "./frame-component.css";

const FrameComponent = ({ className = "" }) => {
  return (
    <section className={`cards-wrapper ${className}`}>
      <div className="cards1">
        <div className="banner1">
          <div className="banner11">
            <h3 className="reserve-your-hotel-container">
              <p className="blank-line">
                <a
                  className="blank-line1"
                  href="https://hotel.check24.de/reisewelt/fussball-em-2024"
                  target="_blank"
                >
                  &nbsp;
                </a>
              </p>
              <p className="reserve-your-hotel">
                Reserve Your hotel, Pursue Your Team
              </p>
            </h3>
          </div>
          <div className="banner2">
            <h3 className="subscribe-our-newsletter">
              Subscribe Our Newsletter
            </h3>
          </div>
        </div>
        <div className="banner3">
          <textarea
            className="banner31"
            placeholder={`
Review Hotel Services Worldwide`}
            rows={13}
            cols={30}
          />
          <div className="banner4">
            <div className="follow-the-lates-container">
              <p className="blank-line2">
                <a
                  className="blank-line3"
                  href="https://hotel.check24.de/reisewelt/instagram-hotels-in-deutschland"
                  target="_blank"
                >
                  <span className="blank-line4">&nbsp;</span>
                </a>
              </p>
              <p className="follow-the-lates-tour-news">
                <b className="follow-the-lates">Follow the Lates Tour News</b>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
