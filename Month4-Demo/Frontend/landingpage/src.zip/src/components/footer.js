import PropTypes from "prop-types";
import "./footer.css";

const Footer = ({ className = "" }) => {
  return (
    <div className={`footer ${className}`}>
      <div className="base" />
      <div className="auto-layout-the-whole-episode">
        <div className="auto-layout-about-us">
          <b className="customer-service">About Us</b>
          <div className="our-story">Our Story</div>
          <div className="work-with-us">Work with us</div>
          <div className="press-media">{`Press & media`}</div>
          <div className="privacy-security">{`Privacy & Security`}</div>
        </div>
        <div className="auto-layout-we-offer">
          <b className="we-offer">We Offer</b>
          <div className="trip-sponsorship">Trip Sponsorship</div>
          <div className="last-minutes-flights">Last Minutes Flights</div>
          <div className="best-deals">Best Deals</div>
          <div className="ai-driven-search">{`AI-Driven Search `}</div>
        </div>
        <div className="auto-layout-headquarters">
          <b className="headquarters">Headquarters</b>
          <div className="england1">England</div>
          <div className="france">France</div>
          <div className="canada">Canada</div>
          <div className="iceland">Iceland</div>
        </div>
        <div className="auto-layout-travel-blogs">
          <b className="travel-blogs">Travel Blogs</b>
          <div className="bali-travel-guide">Bali Travel Guide</div>
          <div className="sri-travel-guide">Sri Travel Guide</div>
          <div className="peru-travel-guide">Peru Travel Guide</div>
          <div className="swiss-travel-guide">Swiss Travel Guide</div>
        </div>
        <div className="auto-layout-activities1">
          <b className="activities">Activities</b>
          <div className="tour-leading">Tour Leading</div>
          <div className="cruising-sailing">{`Cruising & sailing`}</div>
          <div className="camping">{`Camping `}</div>
          <div className="kayaking">Kayaking</div>
        </div>
        <div className="auto-layou-service">
          <b className="service">Service</b>
          <div className="report-error">Report Error</div>
          <div className="ask-online">Ask online</div>
          <div className="travel-insurance">Travel insurance</div>
        </div>
      </div>
      <div className="payment-methods-parent">
        <div className="payment-methods">
          <div className="visa-card">
            <img
              className="visa-logo-icon"
              loading="lazy"
              alt=""
              src="/visalogo.svg"
            />
          </div>
          <img className="amex-icon" loading="lazy" alt="" src="/amex@2x.png" />
          <div className="master-card">
            <img
              className="internationalbankmasterrcard-icon"
              loading="lazy"
              alt=""
              src="/internationalbankmasterrcard@2x.png"
            />
          </div>
          <div className="paypal">
            <img
              className="international-icon"
              loading="lazy"
              alt=""
              src="/international@2x.png"
            />
          </div>
        </div>
        <div className="social-networks-wrapper">
          <div className="social-networks">
            <img
              className="linkedin-icon"
              loading="lazy"
              alt=""
              src="/-linkedin.svg"
            />
            <img
              className="telegram-icon"
              loading="lazy"
              alt=""
              src="/-telegram.svg"
            />
            <img className="twitter-icon" alt="" src="/-twitter.svg" />
            <img className="facebook-icon" alt="" src="/facebook.svg" />
            <img className="instagram-icon" alt="" src="/-instagram.svg" />
          </div>
        </div>
        <div className="send-an-email">
          <div className="input8">
            <div className="e-mail-text">
              <div className="title">Email</div>
            </div>
            <div className="auto-layout-input">
              <div className="text38">
                <img
                  className="iconsofficemail"
                  alt=""
                  src="/iconsofficemail.svg"
                />
                <input
                  className="enter-yout-email"
                  placeholder="enter your email"
                  type="text"
                />
              </div>
              <img
                className="iconsbasesearch1"
                alt=""
                src="/iconsbasesearch1.svg"
              />
            </div>
            <div className="sub-headings">
              <div className="information3">Information</div>
            </div>
          </div>
          <button className="confirm-button">
            <div className="button11">
              <img
                className="vuesaxoutlinearrow-down-icon7"
                alt=""
                src="/vuesaxoutlinearrowdown1.svg"
              />
              <div className="text39">
                <div className="icon-mail">Subscribe</div>
                <img
                  className="vuesaxoutlinetick-square-icon"
                  alt=""
                  src="/vuesaxoutlineticksquare.svg"
                />
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
