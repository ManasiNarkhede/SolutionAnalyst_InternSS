import PropTypes from "prop-types";
import "./search.css";

const Search = ({ className = "" }) => {
  return (
    <div className={`search1 ${className}`}>
      <div className="text5">
        <h3 className="heading">Where is your Next Dream Place?</h3>
        <div className="find-exclusive-genius">
          Find exclusive Genius rewards in every corner of the world!
        </div>
      </div>
      <div className="hotel-search-menue-bar">
        <div className="input">
          <div className="text6">
            <b className="place">Place</b>
          </div>
          <div className="input1">
            <div className="text7">
              <img
                className="iconsbuildhotel"
                alt=""
                src="/iconsbuildhotel.svg"
              />
              <input className="text8" placeholder="Gutenberg" type="text" />
            </div>
          </div>
          <div className="text9">
            <div className="information">Information</div>
          </div>
        </div>
        <div className="input2">
          <div className="text10">
            <b className="vip">VIP</b>
          </div>
          <div className="input3">
            <div className="text11">
              <img
                className="iconstravelstake-off"
                alt=""
                src="/iconstravelstakeoff.svg"
              />
              <div className="long-lasting">Long Lasting</div>
            </div>
            <img
              className="iconseditdrop-down-list"
              alt=""
              src="/iconseditdropdownlist.svg"
            />
          </div>
        </div>
        <div className="input4">
          <div className="text12">
            <b className="passengers-room">Passengers - Room Condition</b>
          </div>
          <div className="input5">
            <div className="text13">
              <img
                className="iconspeoplespeople"
                loading="lazy"
                alt=""
                src="/iconspeoplespeople.svg"
              />
              <div className="adults-3">{`2 Adults - 3 Children `}</div>
            </div>
            <div className="text14">
              <div className="two-rooms">Two Rooms</div>
              <img
                className="iconseditdrop-down-list1"
                alt=""
                src="/iconseditdropdownlist.svg"
              />
            </div>
          </div>
          <div className="text15">
            <div className="information1">Information</div>
          </div>
        </div>
        <div className="input6">
          <div className="text16">
            <b className="check-in-check">Check In -Check Out</b>
          </div>
          <div className="input7">
            <div className="text17">
              <img
                className="iconseditcalendar"
                alt=""
                src="/iconseditcalendar.svg"
              />
              <div className="dec-2023-">{`18 Dec 2023 - 23 Dec 2023  `}</div>
            </div>
            <img
              className="iconstravelslanding"
              alt=""
              src="/iconstravelslanding.svg"
            />
          </div>
          <div className="text18">
            <div className="information2">Information</div>
          </div>
        </div>
        <button className="search2">
          <b className="search3">{`Search `}</b>
        </button>
      </div>
    </div>
  );
};

Search.propTypes = {
  className: PropTypes.string,
};

export default Search;
