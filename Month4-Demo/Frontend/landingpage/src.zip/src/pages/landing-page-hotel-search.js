import HotelSearchHeaderWitheSea from "../components/hotel-search-header-withe-sea";
import Search from "../components/search";
import BannerContent from "../components/banner-content";
import FrameComponent3 from "../components/frame-component3";
import FrameComponent2 from "../components/frame-component2";
import FrameComponent1 from "../components/frame-component1";
import ReviewContainer from "../components/review-container";
import FrameComponent from "../components/frame-component";
import EasySet24AppFooter from "../components/easy-set24-app-footer";
import Footer from "../components/footer";
import FrameFooter from "../components/frame-footer";
import "./landing-page-hotel-search.css";

const LandingPageHotelSearch = () => {
  return (
    <div className="landing-page-hotel-search">
      <section className="hotel-search-menue-wrapper">
        <div className="hotel-search-menue">
          <HotelSearchHeaderWitheSea />
          <Search />
        </div>
      </section>
      <section className="banner-hotel-search">
        <BannerContent />
        <FrameComponent3 />
      </section>
      <FrameComponent2 />
      <FrameComponent1 />
      <ReviewContainer />
      <FrameComponent />
      <EasySet24AppFooter />
      <footer className="footerfinal">
        <Footer />
        <FrameFooter />
      </footer>
    </div>
  );
};

export default LandingPageHotelSearch;
